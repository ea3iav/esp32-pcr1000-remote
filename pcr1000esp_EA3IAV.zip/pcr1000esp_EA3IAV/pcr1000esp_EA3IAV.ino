#include <TFT_eSPI.h>
#include <HardwareSerial.h>

TFT_eSPI tft = TFT_eSPI();
HardwareSerial PCR(2);

// ===== ESTADO =====
float frequency = 95.800;
int currentMode = 6;
int currentFilter = 4;

bool NB=false, AGC=false, ATT=false, ANF=false;

// ===== PANTALLAS =====
enum ScreenState { MAIN, STEP_MENU, FILTER_MENU, KEYPAD };
ScreenState currentScreen = MAIN;

// ===== KEYPAD =====
String inputFreq = "";

// ===== ENCODER =====
#define CLK 33
#define DT  32
#define SW  25

int lastCLK;
unsigned long lastPress=0;

// ===== STEP =====
float stepList[] = {0.001,0.005,0.0125,0.02,0.05,0.1};
int stepIndex = 5;
float step = 0.1;

// ===== S-METER =====
int smeter=0;
unsigned long lastSM=0;

// ===== POTS =====
int lastVol=-1;
int lastSql=-1;

// ===== TOUCH =====
unsigned long lastTouch = 0;

// ================= SETUP =================
void setup(){

  Serial.begin(115200);

  pinMode(CLK,INPUT_PULLUP);
  pinMode(DT,INPUT_PULLUP);
  pinMode(SW,INPUT_PULLUP);

  lastCLK=digitalRead(CLK);

  PCR.begin(9600,SERIAL_8N1,16,17);
  delay(2000);

  PCR.println("H101"); delay(800);
  PCR.println("G301"); delay(800);
  PCR.println("J4040"); delay(500);
  PCR.println("J4100"); delay(500);

  sendFrequency();

  tft.init();
  tft.setRotation(1);
  tft.fillScreen(TFT_BLACK);

  drawUI();
}

// ================= LOOP =================
void loop(){

  handleEncoder();
  handleEncoderButton();
  handleTouch();
  readPots();

  if(millis()-lastSM>200 && currentScreen==MAIN){
    readSMeter();
    lastSM=millis();
  }
}

// ================= FRECUENCIA =================
void sendFrequency(){

  long hz=(long)(frequency*1000000);
  int mhz=hz/1000000;
  int hz_part=hz%1000000;

  char cmd[32];
  sprintf(cmd,"K0%04d%06d%02d%02d00",mhz,hz_part,currentMode,currentFilter);

  PCR.print(cmd); PCR.print("\r\n");
}

// ================= OPCIONES =================
void sendOptions(){

  PCR.println(AGC ? "J4501" : "J4500");
  PCR.println(NB  ? "J4601" : "J4600");
  PCR.println(ATT ? "J4701" : "J4700");
}

// ================= ENCODER =================
void handleEncoder(){

  int clk=digitalRead(CLK);

  if(clk!=lastCLK && currentScreen==MAIN){

    if(digitalRead(DT)!=clk) frequency+=step;
    else frequency-=step;

    frequency=constrain(frequency,0.1,1300);

    sendFrequency();

    drawFrequency();
    drawSMeter();
  }

  lastCLK=clk;
}

// ================= BOTÓN ENCODER =================
void handleEncoderButton(){

  if(digitalRead(SW)==LOW && millis()-lastPress>300){

    stepIndex++;
    if(stepIndex>5)stepIndex=0;

    step=stepList[stepIndex];

    drawUI();
    lastPress=millis();
  }
}

// ================= POTS =================
void readPots(){

  int vol=map(analogRead(34),0,4095,0,255);
  int sql=map(analogRead(35),0,4095,0,255);

  if(abs(vol-lastVol)>3){
    char cmd[10];
    sprintf(cmd,"J40%02X",vol);
    PCR.print(cmd); PCR.print("\r\n");
    lastVol=vol;
  }

  if(abs(sql-lastSql)>3){
    char cmd[10];
    sprintf(cmd,"J41%02X",sql);
    PCR.print(cmd); PCR.print("\r\n");
    lastSql=sql;
  }
}

// ================= S-METER =================
void readSMeter(){

  PCR.print("I1?\r\n");
  delay(10);

  String data="";

  while(PCR.available()){
    data+=(char)PCR.read();
  }

  int pos=data.indexOf("I1");

  if(pos!=-1 && data.length()>=pos+4){

    String hex=data.substring(pos+2,pos+4);
    int val=strtol(hex.c_str(),NULL,16);

    smeter=map(val,0x60,0x90,0,9);
    smeter=constrain(smeter,0,9);

    drawSMeter();
  }
}

// ================= UI =================
void drawUI(){

  currentScreen = MAIN;

  tft.fillScreen(TFT_BLACK);

  drawFrequency();
  tft.drawRect(40,75,200,20,TFT_YELLOW);

  drawSMeter();
  drawButtons();
}

// ================= FRECUENCIA =================
void drawFrequency(){

  tft.fillRect(0,0,320,70,TFT_BLACK);

  tft.setTextColor(TFT_WHITE);
  tft.drawCentreString(String(frequency,3),170,20,6);

  tft.drawString("MHz",260,65,2);

  String stepTxt[]={"1k","5k","12.5k","20k","50k","100k"};
  tft.setTextColor(TFT_CYAN);
  tft.drawString(stepTxt[stepIndex],5,10,2);

  const char* filtTxt[]={"2.8k","6k","15k","50k","230k"};
  tft.setTextColor(TFT_YELLOW);
  tft.drawString(filtTxt[currentFilter],5,40,2);
}

// ================= S-METER =================
void drawSMeter(){

  int x=40,y=75,w=200,h=20;

  tft.fillRect(x+1,y+1,w-2,h-2,TFT_BLACK);

  int fill=map(smeter,0,9,0,w-2);
  uint16_t col=(smeter>=8)?TFT_RED:TFT_YELLOW;

  tft.fillRect(x+1,y+1,fill,h-2,col);

  String txt=(smeter<9)?"S"+String(smeter+1):"S9+";

  tft.setTextColor(TFT_WHITE);
  tft.drawString(txt,x+w-50,y+2,2);
}

// ================= BOTONES =================
void drawBtn(int x,int y,int w,int h,String txt,bool active){

  tft.fillRoundRect(x,y,w,h,5,TFT_DARKGREY);
  tft.drawRoundRect(x,y,w,h,5,TFT_WHITE);

  tft.setTextColor(active?TFT_RED:TFT_WHITE);
  tft.drawCentreString(txt,x+w/2,y+6,2);
}

void drawButtons(){

  int y1=110;

  drawBtn(5,y1,50,30,"AM",currentMode==2);
  drawBtn(60,y1,50,30,"NFM",currentMode==5);
  drawBtn(115,y1,50,30,"WFM",currentMode==6);
  drawBtn(170,y1,50,30,"USB",currentMode==1);
  drawBtn(225,y1,50,30,"LSB",currentMode==0);
  drawBtn(280,y1,35,30,"CW",currentMode==3);

  int y2=150;

  drawBtn(40,y2,50,30,"NB",NB);
  drawBtn(100,y2,50,30,"AGC",AGC);
  drawBtn(160,y2,50,30,"ATT",ATT);
  drawBtn(220,y2,50,30,"ANF",ANF);

  int y3=190;

  tft.fillRoundRect(90,y3,60,30,5,TFT_CYAN);
  tft.setTextColor(TFT_BLACK);
  tft.drawCentreString("STEP",120,y3+6,2);

  tft.fillRoundRect(170,y3,70,30,5,TFT_YELLOW);
  tft.drawCentreString("FLT",205,y3+6,2);
}

// ================= KEYPAD =================
void drawKeypad(){

  tft.fillScreen(TFT_BLACK);

  tft.setTextColor(TFT_GREEN);
  tft.drawCentreString(inputFreq, 160, 5, 4);
  tft.drawString("MHz", 260, 15, 2);

  String keys[4][3] = {
    {"1","2","3"},
    {"4","5","6"},
    {"7","8","9"},
    {".","0","C"}
  };

  int w = 70;
  int h = 40;
  int startX = 10;
  int startY = 40;

  for(int r=0;r<4;r++){
    for(int c=0;c<3;c++){

      int x = startX + c*(w+5);
      int y = startY + r*(h+5);

      tft.fillRoundRect(x,y,w,h,5,TFT_DARKGREY);
      tft.drawRoundRect(x,y,w,h,5,TFT_WHITE);
      tft.drawCentreString(keys[r][c], x+w/2, y+10, 4);
    }
  }

  tft.fillRoundRect(240, 40, 70, 180, 5, TFT_GREEN);
  tft.setTextColor(TFT_BLACK);
  tft.drawCentreString("OK", 275, 120, 4);
}

// ================= TOUCH =================
void handleTouch(){

  uint16_t x,y;

  if (!tft.getTouch(&x,&y)) return;
  if (millis() - lastTouch < 250) return;
  lastTouch = millis();

  y = 240 - y;

  // ===== KEYPAD =====
  if(currentScreen == KEYPAD){

    if(x > 240){
      if(inputFreq.length() > 0){
        frequency = constrain(inputFreq.toFloat(),0.1,1300);
        sendFrequency();
      }
      drawUI();
      waitRelease();
      return;
    }

    int w = 70;
    int h = 40;
    int startX = 10;
    int startY = 40;

    int col = (x - startX) / (w+5);
    int row = (y - startY) / (h+5);

    if(col>=0 && col<3 && row>=0 && row<4){

      String keys[4][3] = {
        {"1","2","3"},
        {"4","5","6"},
        {"7","8","9"},
        {".","0","C"}
      };

      String key = keys[row][col];

      if(key=="C") inputFreq="";
      else if(key=="."){
        if(inputFreq.length()==0) inputFreq="0.";
        else if(inputFreq.indexOf('.')==-1) inputFreq+=".";
      }
      else inputFreq+=key;

      drawKeypad();
    }

    waitRelease();
    return;
  }

 
// ===== CLICK FRECUENCIA SOLO EN MAIN =====
if (currentScreen == MAIN && y < 90){
  currentScreen = KEYPAD;
  inputFreq = String(frequency,3);
  drawKeypad();
  waitRelease();
  return;
}
  // ===== STEP MENU =====
  if(currentScreen==STEP_MENU){

    for(int i=0;i<6;i++){
      int yStart = 40 + i*30;
      int yEnd   = yStart + 30;

      if(y >= yStart && y < yEnd){
        stepIndex = i;
        step = stepList[i];
        break;
      }
    }

    drawUI();
    waitRelease();
    return;
  }

  // ===== FILTER MENU =====
  if(currentScreen==FILTER_MENU){

    for(int i=0;i<5;i++){
      int yStart = 40 + i*30;
      int yEnd   = yStart + 30;

      if(y >= yStart && y < yEnd){
        currentFilter = i;
        sendFrequency();
        break;
      }
    }

    drawUI();
    waitRelease();
    return;
  }

  // ===== MAIN =====
  if (y>190 && y<220 && x>90 && x<150){
    currentScreen=STEP_MENU;
    drawStepMenu();
    waitRelease();
    return;
  }

  if (y>190 && y<220 && x>170){
    currentScreen=FILTER_MENU;
    drawFilterMenu();
    waitRelease();
    return;
  }

  if (y>110 && y<140){

    if(x<55) currentMode=2;
    else if(x<110) currentMode=5;
    else if(x<165) currentMode=6;
    else if(x<220) currentMode=1;
    else if(x<275) currentMode=0;
    else currentMode=3;

    sendFrequency();
    drawUI();
    waitRelease();
    return;
  }

  if (y>150 && y<180){

    if(x>40 && x<90) NB=!NB;
    else if(x>100 && x<150) AGC=!AGC;
    else if(x>160 && x<210) ATT=!ATT;
    else if(x>220 && x<270) ANF=!ANF;

    sendOptions();
    drawButtons();
    waitRelease();
    return;
  }
}

// ================= ANTI REBOTE =================
void waitRelease(){

  uint16_t x,y;
  while(tft.getTouch(&x,&y)){
    delay(10);
  }
  delay(50);
}

// ================= MENÚS =================
void drawStepMenu(){

  tft.fillScreen(TFT_BLACK);

  const char* txt[]={"1 kHz","5 kHz","12.5 kHz","20 kHz","50 kHz","100 kHz"};

  for(int i=0;i<6;i++){
    tft.setTextColor(i==stepIndex?TFT_RED:TFT_WHITE);
    tft.drawCentreString(txt[i],160,40+i*30,2);
  }
}

void drawFilterMenu(){

  tft.fillScreen(TFT_BLACK);

  const char* txt[]={"2.8 kHz","6 kHz","15 kHz","50 kHz","230 kHz"};

  for(int i=0;i<5;i++){
    tft.setTextColor(i==currentFilter?TFT_RED:TFT_WHITE);
    tft.drawCentreString(txt[i],160,40+i*30,2);
  }
}